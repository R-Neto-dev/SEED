const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = 3001;
const DB_PATH = path.join(__dirname, 'db.json');

app.use(cors());
app.use(express.json());

// Helpers para ler e salvar o db.json
function readDB() {
    const raw = fs.readFileSync(DB_PATH, 'utf-8');
    return JSON.parse(raw);
}

function saveDB(data) {
    fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2), 'utf-8');
}

// ─────────────────────────────────────────
// GET /provas — listar todas as provas
// ─────────────────────────────────────────
app.get('/provas', (req, res) => {
    const db = readDB();
    res.json(db.provas);
});

// ─────────────────────────────────────────
// GET /provas/:id — buscar uma prova
// ─────────────────────────────────────────
app.get('/provas/:id', (req, res) => {
    const db = readDB();
    const prova = db.provas.find(p => p.id === parseInt(req.params.id));
    if (!prova) return res.status(404).json({ erro: 'Prova não encontrada' });
    res.json(prova);
});

// ─────────────────────────────────────────
// POST /provas — cadastrar nova prova
// ─────────────────────────────────────────
app.post('/provas', (req, res) => {
    const { nome, materia, turma, data, questoes, status } = req.body;

    if (!nome || !materia || !turma || !data) {
        return res.status(400).json({ erro: 'Campos obrigatórios: nome, materia, turma, data' });
    }

    const db = readDB();
    const novaProva = {
        id: Date.now(),
        nome,
        materia,
        turma,
        data,
        questoes: questoes || 0,
        participacao: '0/' + (questoes || 0),
        status: status || 'Rascunho'
    };

    db.provas.push(novaProva);
    saveDB(db);
    res.status(201).json(novaProva);
});

// ─────────────────────────────────────────
// PUT /provas/:id — editar uma prova
// ─────────────────────────────────────────
app.put('/provas/:id', (req, res) => {
    const db = readDB();
    const index = db.provas.findIndex(p => p.id === parseInt(req.params.id));
    if (index === -1) return res.status(404).json({ erro: 'Prova não encontrada' });

    db.provas[index] = { ...db.provas[index], ...req.body };
    saveDB(db);
    res.json(db.provas[index]);
});

// ─────────────────────────────────────────
// DELETE /provas/:id — remover uma prova
// ─────────────────────────────────────────
app.delete('/provas/:id', (req, res) => {
    const db = readDB();
    const index = db.provas.findIndex(p => p.id === parseInt(req.params.id));
    if (index === -1) return res.status(404).json({ erro: 'Prova não encontrada' });

    db.provas.splice(index, 1);
    saveDB(db);
    res.json({ mensagem: 'Prova removida com sucesso' });
});

app.listen(PORT, () => {
    console.log(`Servidor SEED rodando em http://localhost:${PORT}`);
});
