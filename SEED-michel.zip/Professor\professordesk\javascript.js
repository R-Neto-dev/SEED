const API = 'http://localhost:3001';

const eventsData = [];
let currentCalendarDate = new Date(2026, 3);

// ─────────────────────────────────────────
// PROVAS — API
// ─────────────────────────────────────────
async function fetchProvas() {
    try {
        const res = await fetch(`${API}/provas`);
        const provas = await res.json();
        renderProvasTable(provas);
    } catch (e) {
        console.error('Erro ao carregar provas:', e);
        document.getElementById('provasTableBody').innerHTML =
            '<tr><td colspan="6" style="text-align:center;color:#ef4444">Servidor offline. Inicie o backend.</td></tr>';
    }
}

function renderProvasTable(provas) {
    const container = document.getElementById('provasTableBody');
    if (!container) return;

    if (provas.length === 0) {
        container.innerHTML = '<tr><td colspan="6" style="text-align:center;color:#888">Nenhuma prova cadastrada.</td></tr>';
        return;
    }

    container.innerHTML = provas.map(prova => {
        const statusClass = prova.status === 'Ativa' ? 'ativa'
            : prova.status === 'Encerrada' ? 'encerrada'
            : 'rascunho';

        const dataFormatada = prova.data
            ? new Date(prova.data + 'T00:00:00').toLocaleDateString('pt-BR')
            : '—';

        return `
        <tr>
            <td>
                <div class="prova-info">
                    <div class="prova-icon"><i class='bx bx-file'></i></div>
                    <span>${prova.nome}</span>
                </div>
            </td>
            <td>${prova.materia}</td>
            <td>${prova.turma}</td>
            <td>${dataFormatada}</td>
            <td>${prova.questoes}</td>
            <td><span class="status ${statusClass}">${prova.status}</span></td>
            <td>
                <button class="btn-acao btn-editar" onclick="abrirModalEdicao(${prova.id})">
                    <i class='bx bx-edit'></i>
                </button>
                <button class="btn-acao btn-excluir" onclick="excluirProva(${prova.id})">
                    <i class='bx bx-trash'></i>
                </button>
            </td>
        </tr>
        `;
    }).join('');
}

async function salvarProva() {
    const id = document.getElementById('modal-id').value;
    const payload = {
        nome:     document.getElementById('modal-nome').value.trim(),
        materia:  document.getElementById('modal-materia').value.trim(),
        turma:    document.getElementById('modal-turma').value.trim(),
        data:     document.getElementById('modal-data').value,
        questoes: parseInt(document.getElementById('modal-questoes').value) || 0,
        status:   document.getElementById('modal-status').value
    };

    if (!payload.nome || !payload.materia || !payload.turma || !payload.data) {
        alert('Preencha todos os campos obrigatórios.');
        return;
    }

    const method = id ? 'PUT' : 'POST';
    const url    = id ? `${API}/provas/${id}` : `${API}/provas`;

    try {
        const res = await fetch(url, {
            method,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });

        if (!res.ok) throw new Error('Erro na resposta do servidor');
        fecharModal();
        fetchProvas();
    } catch (e) {
        alert('Erro ao salvar prova. Verifique se o servidor está rodando.');
    }
}

async function excluirProva(id) {
    if (!confirm('Deseja realmente excluir esta prova?')) return;
    try {
        await fetch(`${API}/provas/${id}`, { method: 'DELETE' });
        fetchProvas();
    } catch (e) {
        alert('Erro ao excluir prova.');
    }
}

async function abrirModalEdicao(id) {
    try {
        const res = await fetch(`${API}/provas/${id}`);
        const prova = await res.json();
        document.getElementById('modal-id').value      = prova.id;
        document.getElementById('modal-nome').value    = prova.nome;
        document.getElementById('modal-materia').value = prova.materia;
        document.getElementById('modal-turma').value   = prova.turma;
        document.getElementById('modal-data').value    = prova.data;
        document.getElementById('modal-questoes').value = prova.questoes;
        document.getElementById('modal-status').value  = prova.status;
        document.getElementById('modal-titulo').textContent = 'Editar Prova';
        document.getElementById('modal-prova').classList.add('open');
    } catch (e) {
        alert('Erro ao carregar dados da prova.');
    }
}

function abrirModalCadastro() {
    document.getElementById('modal-id').value       = '';
    document.getElementById('modal-nome').value     = '';
    document.getElementById('modal-materia').value  = '';
    document.getElementById('modal-turma').value    = '';
    document.getElementById('modal-data').value     = '';
    document.getElementById('modal-questoes').value = '';
    document.getElementById('modal-status').value   = 'Rascunho';
    document.getElementById('modal-titulo').textContent = 'Nova Prova';
    document.getElementById('modal-prova').classList.add('open');
}

function fecharModal() {
    document.getElementById('modal-prova').classList.remove('open');
}

// ─────────────────────────────────────────
// CALENDÁRIO
// ─────────────────────────────────────────
function renderCalendar() {
    const year = currentCalendarDate.getFullYear();
    const month = currentCalendarDate.getMonth();
    const firstDay = new Date(year, month, 1).getDay();
    const daysInMonth = new Date(year, month + 1, 0).getDate();

    const container = document.getElementById('calendarDays');
    if (!container) return;
    let html = '';

    for (let i = 0; i < firstDay; i++) html += '<div class="calendar-day"></div>';

    for (let d = 1; d <= daysInMonth; d++) {
        const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
        const dayEvents = eventsData.filter(ev => ev.date === dateStr);
        let eventClass = dayEvents.length ? `has-event ${dayEvents[0].type}` : '';
        const isToday = dateStr === new Date().toISOString().slice(0, 10);
        html += `<div class="calendar-day ${eventClass} ${isToday ? 'today' : ''}"
                 onclick="alert('${dayEvents.map(e => e.title).join('\\n') || 'Sem eventos'}')">${d}</div>`;
    }

    container.innerHTML = html;

    const monthNames = ['Janeiro','Fevereiro','Março','Abril','Maio','Junho',
                        'Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'];
    const headerTitle = document.querySelector('.calendar-card .card-header h2');
    if (headerTitle) headerTitle.innerHTML = `<i class='bx bx-calendar'></i> ${monthNames[month]} ${year}`;
}

// ─────────────────────────────────────────
// PÁGINAS
// ─────────────────────────────────────────
function setupPages() {
    const navLinks = document.querySelectorAll('.nav-item[data-page]');
    const pages = document.querySelectorAll('.page');

    navLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const pageId = link.getAttribute('data-page');
            navLinks.forEach(l => l.classList.remove('active'));
            link.classList.add('active');
            pages.forEach(p => p.classList.remove('active'));
            const activePage = document.getElementById(`${pageId}-page`);
            if (activePage) activePage.classList.add('active');
            if (pageId === 'provas') fetchProvas();
        });
    });

    document.querySelector('.nav-item[data-page="dashboard"]')?.classList.add('active');

    document.querySelectorAll('.view-all-link').forEach(btn => {
        btn.addEventListener('click', (e) => {
            e.preventDefault();
            const target = btn.getAttribute('data-page');
            document.querySelector(`.nav-item[data-page="${target}"]`)?.click();
        });
    });
}

// ─────────────────────────────────────────
// TURMAS / RESULTADOS / DASHBOARD (mantidos)
// ─────────────────────────────────────────
function fillTurmas() {
    const turmas = [
        { nome: '6º Ano', alunos: 32, media: 7.5 },
        { nome: '7º Ano', alunos: 30, media: 8.0 },
        { nome: '8º Ano', alunos: 32, media: 8.3 }
    ];
    const container = document.querySelector('#turmas-page .card');
    if (!container) return;
    container.innerHTML = `
        <div class="card-header"><h2>Turmas</h2></div>
        <div class="results-list">
            ${turmas.map(t => `
                <div class="result-item">
                    <div class="result-info">
                        <div class="result-name">${t.nome}</div>
                        <div class="result-date">${t.alunos} alunos</div>
                    </div>
                    <div class="result-grade">${t.media}</div>
                </div>
            `).join('')}
        </div>`;
}

function fillResultadosTable() {
    const resultados = [
        { turma: '6º Ano B', prova: 'Prova Bimestral', media: '7.5', participacao: '30/32', status: 'Regular' },
        { turma: '7º Ano C', prova: 'Avaliação Final',  media: '9.0', participacao: '30/30', status: 'Excelente' },
        { turma: '8º Ano A', prova: 'Prova Mensal',     media: '7.5', participacao: '28/32', status: 'Regular' }
    ];
    const container = document.getElementById('resultadosTableBody');
    if (!container) return;
    container.innerHTML = resultados.map(r => {
        const cls = r.status === 'Excelente' ? 'ativa' : 'encerrada';
        return `<tr>
            <td>${r.turma}</td><td>${r.prova}</td><td>${r.media}</td>
            <td>${r.participacao}</td>
            <td><span class="status ${cls}">${r.status}</span></td>
        </tr>`;
    }).join('');
}

// ─────────────────────────────────────────
// MENU MOBILE / CALENDÁRIO NAV / LOGOUT
// ─────────────────────────────────────────
function mobileMenu() {
    const btn = document.getElementById('menuBtn');
    const sidebar = document.querySelector('.sidebar');
    btn?.addEventListener('click', () => sidebar.classList.toggle('open'));
    document.addEventListener('click', (e) => {
        if (sidebar?.classList.contains('open') && !sidebar.contains(e.target) && !btn?.contains(e.target))
            sidebar.classList.remove('open');
    });
}

function initCalendarNav() {
    document.getElementById('prevMonth')?.addEventListener('click', () => {
        currentCalendarDate.setMonth(currentCalendarDate.getMonth() - 1);
        renderCalendar();
    });
    document.getElementById('nextMonth')?.addEventListener('click', () => {
        currentCalendarDate.setMonth(currentCalendarDate.getMonth() + 1);
        renderCalendar();
    });
}

function logout() {
    const userName = document.querySelector('.user-name')?.textContent.trim() || 'usuário';
    document.getElementById('logout')?.addEventListener('click', (e) => {
        e.preventDefault();
        if (confirm('Deseja sair da sua conta?')) alert(`Até logo, ${userName}!`);
    });
}

// ─────────────────────────────────────────
// INIT
// ─────────────────────────────────────────
function init() {
    renderCalendar();
    setupPages();
    fillTurmas();
    fillResultadosTable();
    mobileMenu();
    initCalendarNav();
    logout();

    // Botão Nova Prova
    document.getElementById('btn-nova-prova')?.addEventListener('click', abrirModalCadastro);
    document.getElementById('btn-cancelar-modal')?.addEventListener('click', fecharModal);
    document.getElementById('btn-salvar-modal')?.addEventListener('click', salvarProva);

    // Fechar modal clicando fora
    document.getElementById('modal-prova')?.addEventListener('click', (e) => {
        if (e.target.id === 'modal-prova') fecharModal();
    });
}

init();
